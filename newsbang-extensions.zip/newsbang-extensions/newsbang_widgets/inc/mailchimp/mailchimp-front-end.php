<?php	
	echo $before_widget;
	$add_sub_title = NULL;
	if ( !empty( $mailchimp_sub_title ) ){
		$add_sub_title = '<p class="widget-sub-title">' . $mailchimp_sub_title . '</p>';
	}
	if ( !empty( $mailchimp_title ) ) {
		echo $before_title . $mailchimp_title . $after_title;
	}
	echo $add_sub_title;
?>

<form class="subscription-form" id="mailchimp">
	<div class="form-group">
		<input class="form-control" type="email" name="subscriber-email" id="subscriber-email" placeholder="Enter email..." required />
	</div>
	<button class="btn btn-primary btn-block" type="submit">Subscribe</button>
	
	<!-- success and error messages -->
	<div class="text-center">
		<div class="subscription-success text-success"></div>
		<div class="subscription-error text-danger"></div>
	</div>
</form>

<?php echo $after_widget; ?>

<script type="text/javascript">
jQuery(document).ready( function($){	
	'use strict';	
	$('#mailchimp').ajaxChimp({
		callback: mailchimpCallback,
		url: "<?php echo $mailchimp_form_url; ?>"
		//replace above url with your own mailchimp post url inside the "".
		//to learn how to get your own URL, please check documentation file.
	});	
	function mailchimpCallback(resp) {
		 if (resp.result === 'success') {
			$('#mailchimp .subscription-success').html('<i class="icon_check_alt2"></i>' + resp.msg).slideDown(1000);
			$('#mailchimp .subscription-error').slideUp(500);
			
		} else if(resp.result === 'error') {
			$('#mailchimp .subscription-success').slideUp(500);
			$('#mailchimp .subscription-error').html('<i class="icon_close_alt2"></i>' + resp.msg).slideDown(1000);
		}  
	}
});
</script>