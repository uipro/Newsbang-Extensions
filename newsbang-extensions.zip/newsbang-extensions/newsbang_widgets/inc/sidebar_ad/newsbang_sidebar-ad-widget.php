<p>
	<label>Image URL</label>
	<input class="widefat" name="<?php echo $this->get_field_name('ad_img_url'); ?>" type="text" value="<?php echo $ad_img_url; ?>">
</p>
<p>
	<label>Ad URL (referral link)</label>
	<input class="widefat" name="<?php echo $this->get_field_name('ad_link'); ?>" type="text" value="<?php echo $ad_link; ?>">
</p>