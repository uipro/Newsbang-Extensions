<?php
	
	echo $before_widget;
	if ( !empty( $flickr_title ) ) {
		echo $before_title . $flickr_title . $after_title;
	}	
	echo '<ul class="flickr-feed"></ul>';	
	echo $after_widget;

?>
<script type="text/javascript">
jQuery(document).ready( function($){	
	'use strict';	
	$('.flickr-feed').jflickrfeed({
		limit: <?php echo $flickr_feed_count ?>,
		qstrings: {
			id: '<?php echo $flickr_feed ?>'
		},
		itemTemplate: '<li><a href="{{image_b}}"><img src="{{image_s}}" alt="{{title}}" /></a></li>'
	});
});
</script>
