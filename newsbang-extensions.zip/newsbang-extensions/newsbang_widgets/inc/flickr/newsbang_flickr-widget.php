<p>
	<label>Title</label>
	<input class="widefat" name="<?php echo $this->get_field_name('flickr_title'); ?>" type="text" value="<?php echo $flickr_title; ?>">
</p>
<p>
	<label>Your Flickr ID</label>
	<input class="widefat" name="<?php echo $this->get_field_name('flickr_feed'); ?>" type="text" value="<?php echo $flickr_feed; ?>">
</p>
<p>
	<label>Images Count</label>
	<input class="widefat" name="<?php echo $this->get_field_name('flickr_feed_count'); ?>" type="text" value="<?php echo $flickr_feed_count; ?>">
</p>