<?php
if( ! function_exists( 'newsbang_share_links_js' ) ){
	function newsbang_share_links_js() {
		if ( is_single() ) {
			wp_enqueue_script( 'newsbang_share_js', plugin_dir_url( __FILE__ ) . '/newsbang_share/share-links.js', array('jquery'), '', true );
		}
	}
}
add_action( 'wp_enqueue_scripts', 'newsbang_share_links_js' );
?>

<ul id="share-list" class="share-list clearfix">
	<li><a class="facebook" href="javascript:void(0);" title="<?php echo esc_attr__( 'Share on facebook', 'newsbang' ); ?>"><span><?php echo esc_html__( 'facebook', 'newsbang' ); ?></span> <i class="fa fa-facebook"></i></a></li>
	<li><a class="twitter" href="javascript:void(0);" title="<?php echo esc_attr__( 'Share on twitter', 'newsbang' ); ?>"><span><?php echo esc_html__( 'twitter', 'newsbang' ); ?></span> <i class="fa fa-twitter"></i></a></li>
	<li><a class="linkedin" href="javascript:void(0);" title="<?php echo esc_attr__( 'Share on linkedin', 'newsbang' ); ?>"><span><?php echo esc_html__( 'linkedin', 'newsbang' ); ?></span> <i class="fa fa-linkedin"></i></a></li>
	<li><a class="pinterest" href="javascript:void(0);" title="<?php echo esc_attr__( 'Share on pinterest', 'newsbang' ); ?>"><span><?php echo esc_html__( 'pinterest', 'newsbang' ); ?></span> <i class="fa fa-pinterest-p"></i></a></li>
	<li><a class="google-plus" href="javascript:void(0);" title="<?php echo esc_attr__( 'Share on google plus', 'newsbang' ); ?>"><span><?php echo esc_html__( 'google', 'newsbang' ); ?></span> <i class="fa fa-google-plus"></i></a></li>
	<li><a class="reddit" href="javascript:void(0);" title="<?php echo esc_attr__( 'Share on reddit', 'newsbang' ); ?>"><span><?php echo esc_html__( 'reddit', 'newsbang' ); ?></span> <i class="fa fa-reddit-alien"></i></a></li>
</ul>

<?php

if( ! function_exists( 'get_share_links' ) ){
	function get_share_links($atts) {
		return 'Hello';
	}
}
add_shortcode('share_links', 'get_share_links');

?>