<?php
if( ! function_exists( 'newsbang_share_links_js' ) ){
	function newsbang_share_links_js() {
		if ( is_single() ) {
			wp_enqueue_script( 'newsbang_share_js', plugin_dir_url( __FILE__ ) . '/newsbang_share/share-links.js', array('jquery'), '', true );
		}
	}
}
add_action( 'wp_enqueue_scripts', 'newsbang_share_links_js' );

if( ! function_exists( 'get_share_links' ) ){
	function get_share_links($atts) {
		return '<ul id="share-list" class="share-list clearfix">
		<li><a class="facebook" href="javascript:void(0);" title="' . esc_attr__( 'Share on facebook', 'newsbang-extensions' ) . '"><span>' . esc_html__( 'facebook', 'newsbang-extensions' ) . '</span> <i class="fa fa-facebook"></i></a></li>
		
		<li><a class="twitter" href="javascript:void(0);" title="' . esc_attr__( 'Share on twitter', 'newsbang-extensions' ) . '"><span>' . esc_html__( 'twitter', 'newsbang-extensions' ) . '</span> <i class="fa fa-twitter"></i></a></li>
		
		<li><a class="linkedin" href="javascript:void(0);" title="' . esc_attr__( 'Share on linkedin', 'newsbang-extensions' ) . '"><span>' . esc_html__( 'linkedin', 'newsbang-extensions' ) . '</span> <i class="fa fa-linkedin"></i></a></li>
		
		<li><a class="pinterest" href="javascript:void(0);" title="' . esc_attr__( 'Share on pinterest', 'newsbang-extensions' ) . '"><span>' . esc_html__( 'pinterest', 'newsbang-extensions' ) . '</span> <i class="fa fa-pinterest-p"></i></a></li>
		
		<li><a class="google-plus" href="javascript:void(0);" title="' . esc_attr__( 'Share on google plus', 'newsbang-extensions' ) . '"><span>' . esc_html__( 'google', 'newsbang-extensions' ) . '</span> <i class="fa fa-google-plus"></i></a></li>
		
		<li><a class="reddit" href="javascript:void(0);" title="' . esc_attr__( 'Share on reddit', 'newsbang-extensions' ) . '"><span>' . esc_html__( 'reddit', 'newsbang-extensions' ) . '</span> <i class="fa fa-reddit-alien"></i></a></li>
		</ul>';
	}
}
add_shortcode('share_links', 'get_share_links');

?>