<?php

/*
*  Meta box - options
*
*  This template file is used when editing a field group and creates the interface for editing options.
*
*  @type	template
*  @date	23/06/12
*/


// global
global $post;

	
// vars
$options = apply_filters('acf/field_group/get_options', array(), $post->ID);
	

?>
<table class="acf_input widefat" id="acf_options">
	<tr>
		<td class="label">
			<label for=""><?php _e("Order No.", 'newsbang-extensions'); ?></label>
			<p class="description"><?php _e("Field groups are created in order <br />from lowest to highest", 'newsbang-extensions'); ?></p>
		</td>
		<td>
			<?php 
			
			do_action('acf/create_field', array(
				'type'	=>	'number',
				'name'	=>	'menu_order',
				'value'	=>	$post->menu_order,
			));
			
			?>
		</td>
	</tr>
	<tr>
		<td class="label">
			<label for=""><?php _e("Position", 'newsbang-extensions'); ?></label>
		</td>
		<td>
			<?php 
			
			do_action('acf/create_field', array(
				'type'	=>	'select',
				'name'	=>	'options[position]',
				'value'	=>	$options['position'],
				'choices' => array(
					'acf_after_title'	=>	__("High (after title)", 'newsbang-extensions'),
					'normal'			=>	__("Normal (after content)", 'newsbang-extensions'),
					'side'				=>	__("Side", 'newsbang-extensions'),
				),
				'default_value' => 'normal'
			));

			?>
		</td>
	</tr>
	<tr>
		<td class="label">
			<label for="post_type"><?php _e("Style", 'newsbang-extensions'); ?></label>
		</td>
		<td>
			<?php 
			
			do_action('acf/create_field', array(
				'type'	=>	'select',
				'name'	=>	'options[layout]',
				'value'	=>	$options['layout'],
				'choices' => array(
					'no_box'			=>	__("Seamless (no metabox)", 'newsbang-extensions'),
					'default'			=>	__("Standard (WP metabox)", 'newsbang-extensions'),
				)
			));
			
			?>
		</td>
	</tr>
	<tr id="hide-on-screen">
		<td class="label">
			<label for="post_type"><?php _e("Hide on screen", 'newsbang-extensions'); ?></label>
			<p class="description"><?php _e("<b>Select</b> items to <b>hide</b> them from the edit screen", 'newsbang-extensions'); ?></p>
			<p class="description"><?php _e("If multiple field groups appear on an edit screen, the first field group's options will be used. (the one with the lowest order number)", 'newsbang-extensions'); ?></p>
		</td>
		<td>
			<?php 
			
			do_action('acf/create_field', array(
				'type'	=>	'checkbox',
				'name'	=>	'options[hide_on_screen]',
				'value'	=>	$options['hide_on_screen'],
				'choices' => array(
					'permalink'			=>	__("Permalink", 'newsbang-extensions'),
					'the_content'		=>	__("Content Editor", 'newsbang-extensions'),
					'excerpt'			=>	__("Excerpt", 'newsbang-extensions'),
					'custom_fields'		=>	__("Custom Fields", 'newsbang-extensions'),
					'discussion'		=>	__("Discussion", 'newsbang-extensions'),
					'comments'			=>	__("Comments", 'newsbang-extensions'),
					'revisions'			=>	__("Revisions", 'newsbang-extensions'),
					'slug'				=>	__("Slug", 'newsbang-extensions'),
					'author'			=>	__("Author", 'newsbang-extensions'),
					'format'			=>	__("Format", 'newsbang-extensions'),
					'featured_image'	=>	__("Featured Image", 'newsbang-extensions'),
					'categories'		=>	__("Categories", 'newsbang-extensions'),
					'tags'				=>	__("Tags", 'newsbang-extensions'),
					'send-trackbacks'	=>	__("Send Trackbacks", 'newsbang-extensions'),
				)
			));
			
			?>
		</td>
	</tr>
</table>